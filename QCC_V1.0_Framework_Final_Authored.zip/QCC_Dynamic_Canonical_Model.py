# Quantum Coherence Cosmology (QCC) Canonical Dynamic Model
# Full support for φ², |φ|, φ⁴+φ″², kernel, well, and burst modes

import numpy as np
import pandas as pd
from scipy.interpolate import interp1d
from scipy.integrate import solve_ivp
from sklearn.metrics import mean_squared_error
import pywt

class QCCModel:
    def __init__(self, A0=1e-5, z0=1.0, sigma=0.75, lambda_phi=0.9, gamma=0.5, scale_mode=None):
        self.A0 = A0
        self.z0 = z0
        self.sigma = sigma
        self.lambda_phi = lambda_phi
        self.gamma = gamma
        self.scale_mode = scale_mode
        self.z_eval = np.linspace(z0, 2.5, 1000)
        self.z_span = (z0, 2.5)

    def initial_phi(self, z):
        return self.A0 * np.exp(-((z - self.z0) ** 2) / (2 * self.sigma ** 2)) * np.sin(2 * np.pi * z / self.lambda_phi)

    def dV_dphi(self, phi):
        return phi ** 3

    def phi_ode(self, z, y):
        phi, dphi = y
        ddphi = -self.dV_dphi(phi) - self.gamma * dphi
        return [dphi, ddphi]

    def solve_field(self):
        y0 = [self.initial_phi(self.z0), 1e-6]
        sol = solve_ivp(self.phi_ode, self.z_span, y0, t_eval=self.z_eval, method='RK45')
        self.z_vals = sol.t
        self.phi_vals = sol.y[0]
        self.phi_prime = sol.y[1]
        self.phi_double_prime = np.gradient(self.phi_prime, self.z_vals)

        coeffs = pywt.wavedec(self.phi_vals, wavelet='db4', level=3)
        lambda_wavelet = np.sqrt(np.mean(np.concatenate(coeffs) ** 2))
        self.phi_vals /= lambda_wavelet
        self.phi_prime /= lambda_wavelet
        self.phi_double_prime /= lambda_wavelet

        self.kernel = self.phi_prime**2 + self.phi_double_prime**2
        self.phi_well = -self.phi_vals ** 4
        self.phi_burst = self.phi_double_prime ** 2
        self.phi_sq = self.phi_vals ** 2
        self.phi_abs = np.abs(self.phi_vals)
        self.combo1 = self.phi_vals ** 4 + self.phi_double_prime ** 2

    def project_to(self, z_data, mode="kernel"):
        z_data = np.clip(z_data, self.z_vals[0], self.z_vals[-1])
        field_map = {
            "kernel": self.kernel,
            "well": self.phi_well,
            "burst": self.phi_burst,
            "phi_sq": self.phi_sq,
            "phi_abs": self.phi_abs,
            "combo1": self.combo1
        }
        if mode not in field_map:
            raise ValueError("Unsupported mode")
        return interp1d(self.z_vals, field_map[mode], fill_value="extrapolate")(z_data)

    def evaluate_rms(self, z_data, observed_data, mode="kernel"):
        prediction = self.project_to(z_data, mode=mode)
        return np.sqrt(mean_squared_error(observed_data, prediction))
