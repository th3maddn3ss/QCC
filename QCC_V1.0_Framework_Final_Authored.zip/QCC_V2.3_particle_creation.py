
import numpy as np
from scipy.integrate import simps

def find_particle_bubbles(z, phi, energy_target=0.511, delta_z=0.01, energy_tolerance=0.05, gamma=0.1):
    '''
    Scan the φ(z) field for coherence bubbles matching the electron mass energy (~0.511 MeV).

    Parameters:
        z : array_like - redshift values
        phi : array_like - φ(z) field values
        energy_target : float - energy target in MeV
        delta_z : float - width around candidate center to integrate over
        energy_tolerance : float - how close energy must match (MeV)
        gamma : float - damping coefficient used in field evolution

    Returns:
        List of candidate bubble dictionaries with z-position and field metadata
    '''
    dz = np.gradient(z)
    phi_prime = np.gradient(phi, dz)
    phi_double_prime = np.gradient(phi_prime, dz)

    # QCC V2.3 defines energy density from φ′² and φ⁴ terms
    energy_density = phi_prime**2 + 0.25 * phi**4

    candidates = []

    for i in range(1, len(z)-1):
        # Identify u-well (local φ″ minimum)
        if phi_double_prime[i-1] > phi_double_prime[i] < phi_double_prime[i+1]:
            z_start = max(0, i - int(delta_z / dz[i]))
            z_end   = min(len(z)-1, i + int(delta_z / dz[i]))
            z_window = z[z_start:z_end]
            E_local = simps(energy_density[z_start:z_end], z_window)

            if abs(E_local - energy_target) < energy_tolerance:
                candidates.append({
                    'z': z[i],
                    'E_MeV': E_local,
                    'phi': phi[i],
                    'phi_prime': phi_prime[i],
                    'phi_double_prime': phi_double_prime[i],
                    'type': 'u-well'
                })

    return candidates
