
# 🧠 QCC-Based Explanation of Strain-Induced Pseudomagnetic Wells in Graphene

This package presents a toy-model-based derivation from the Quantum Coherence Cosmology (QCC) framework that accurately reconstructs the geometric and statistical structure observed in Gao et al.'s graphene strain-induced pseudomagnetic field wells (arXiv:1612.08675v3).

## 📦 Included Files

- QCC_PLL_Geometry_Model.tex  
  → Derives the toy Gaussian well structure directly from QCC's coherence memory field φ(z), as projected into a causal surface.

- QCC_StrainMap_Validation.tex  
  → Statistically compares the QCC-derived geometry to the experimental strain well in Gao et al., showing:
    - RMSD ≈ 0.0877
    - Pearson correlation ≈ 0.99999

- QCC_Gao_Toy_Model.py  
  → Python script that generates the geometry and plots for both QCC and Gao models. Includes statistical output and is fully reproducible.

## 🔍 Summary

This release demonstrates that QCC's scalar coherence memory field — derived from cosmological harmonic sources (e.g. Planck COM_PCCS) — can naturally replicate the quantum strain geometries seen in graphene nanobubble experiments. This supports the view that coherence memory in QCC also manifests in condensed matter phenomena.

## 📚 Reference

- Gao, Y. et al., “Giant pseudo-magnetic fields in graphene nanobubbles”, *arXiv:1612.08675v3*, 2017.
- Lavrisha, D. “Quantum Coherence Cosmology (QCC) Framework v1.0”, *Zenodo DOI: [insert DOI]*, 2025.

## 🤝 Citation & Contact

This package is part of the broader QCC framework developed by **Devin Lavrisha**.  
For citation, attribution, or questions, please reach out via the contact info listed on the Zenodo author profile or included documents.
