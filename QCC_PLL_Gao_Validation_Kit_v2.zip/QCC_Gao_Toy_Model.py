
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from scipy.stats import pearsonr

def gaussian_well(x, y, phi_mid=1.0, sigma=1.0, scale=1.0):
    return -scale * phi_mid * np.exp(-(x**2 + y**2) / (2 * sigma**2))

def generate_grid(x_range=(-5, 5), y_range=(-5, 5), resolution=100):
    x = np.linspace(x_range[0], x_range[1], resolution)
    y = np.linspace(y_range[0], y_range[1], resolution)
    X, Y = np.meshgrid(x, y)
    return X, Y

def compute_models(X, Y, phi_mid=1.0, sigma=1.0):
    V_qcc = gaussian_well(X, Y, phi_mid, sigma, scale=1.0)
    V_gao = gaussian_well(X, Y, phi_mid, sigma, scale=1.5)
    return V_qcc, V_gao

def statistical_comparison(V1, V2):
    rmsd = np.sqrt(np.mean((V1 - V2)**2))
    r, _ = pearsonr(V1.flatten(), V2.flatten())
    return rmsd, r

if __name__ == "__main__":
    X, Y = generate_grid()
    V_qcc, V_gao = compute_models(X, Y)
    rmsd, r = statistical_comparison(V_qcc, V_gao)

    print(f"RMSD between QCC and Gao models: {rmsd:.5f}")
    print(f"Pearson correlation: {r:.5f}")

    fig, axs = plt.subplots(1, 2, figsize=(12, 5))
    c1 = axs[0].contourf(X, Y, V_qcc, cmap=cm.viridis)
    axs[0].set_title("QCC-Derived Geometry")
    fig.colorbar(c1, ax=axs[0])
    c2 = axs[1].contourf(X, Y, V_gao, cmap=cm.plasma)
    axs[1].set_title("Gao et al. Geometry")
    fig.colorbar(c2, ax=axs[1])
    plt.tight_layout()
    plt.show()
